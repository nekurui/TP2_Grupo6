import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Placeholder from "./pages/Placeholder";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const placeholderRoutes: { path: string; title: string }[] = [
  { path: "/nosotros", title: "Nosotros" },
  { path: "/servicios", title: "Servicios" },
  { path: "/precios", title: "Precios" },
  { path: "/paginas", title: "Páginas" },
  { path: "/contacto", title: "Contacto" },
  { path: "/equipo", title: "Nuestro Equipo" },
  { path: "/testimonios", title: "Testimonios" },
  { path: "/turnos", title: "Turnos/Citas" },
  { path: "/buscar-medico", title: "Buscar Médico" },
  { path: "/blog", title: "Blog" },
];

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          {placeholderRoutes.map((route) => (
            <Route
              key={route.path}
              path={route.path}
              element={<Placeholder title={route.title} />}
            />
          ))}
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
