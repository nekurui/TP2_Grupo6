import { Link } from "react-router-dom";
import SocialIcon, { SocialPlatform } from "./SocialIcon";

const quickLinks = [
  { label: "Inicio", to: "/" },
  { label: "Nosotros", to: "/nosotros" },
  { label: "Servicios", to: "/servicios" },
  { label: "Precios", to: "/precios" },
  { label: "Contacto", to: "/contacto" },
];

const pageLinks = [
  { label: "Nuestro equipo", to: "/equipo" },
  { label: "Testimonios", to: "/testimonios" },
  { label: "Turnos/Citas", to: "/turnos" },
  { label: "Buscar Médico", to: "/buscar-medico" },
  { label: "Blog", to: "/blog" },
];

const socialLinks: { platform: SocialPlatform; href: string; label: string }[] = [
  { platform: "facebook", href: "https://facebook.com", label: "Facebook" },
  { platform: "instagram", href: "https://instagram.com", label: "Instagram" },
  { platform: "linkedin", href: "https://linkedin.com", label: "LinkedIn" },
  { platform: "youtube", href: "https://youtube.com", label: "YouTube" },
];

export default function Footer() {
  return (
    <footer className="w-full bg-brand-navy text-white">
      <div className="mx-auto max-w-[1440px] px-6 py-16 lg:px-[80px]">
        <div className="grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <h3 className="text-2xl font-bold sm:text-[28px]">Medicuyo</h3>
            <p className="mt-6 text-lg font-bold">Contactanos</p>
            <p className="mt-4 text-sm font-bold leading-relaxed tracking-wide text-white/80">
              Mendoza, Argentina
              <br />
              +54 261 449 4000
              <br />
              medicuyo@ingenieria.uncuyo.ar
            </p>
          </div>

          <div>
            <h4 className="text-xl font-bold">Enlaces Rápidos</h4>
            <ul className="mt-5 space-y-3">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.to}
                    className="text-sm font-bold text-white/80 hover:text-brand-cyan"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-xl font-bold">Páginas</h4>
            <ul className="mt-5 space-y-3">
              {pageLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.to}
                    className="text-sm font-bold text-white/80 hover:text-brand-cyan"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-xl font-bold">Boletín Informativo</h4>
            <p className="mt-5 text-sm font-bold text-white/80">
              Recibe novedades y noticias de Medicuyo.
            </p>
            <form
              className="mt-4 flex overflow-hidden rounded-[5px] bg-white"
              onSubmit={(e) => e.preventDefault()}
            >
              <input
                type="email"
                required
                placeholder="Tu correo electrónico"
                className="w-full min-w-0 bg-transparent px-4 py-3 text-sm font-bold text-slate-500 outline-none placeholder:text-slate-500"
              />
              <button
                type="submit"
                className="shrink-0 bg-brand-cyan px-5 py-3 text-base font-bold text-white hover:brightness-95"
              >
                Enviar
              </button>
            </form>
          </div>
        </div>

        <div className="mt-14 border-t border-white/20 pt-8">
          <div className="flex flex-col items-center justify-between gap-6 sm:flex-row">
            <p className="text-sm font-bold text-white/90">
              © 2026 Medicuyo. Todos los derechos reservados.
            </p>
            <div className="flex items-center gap-6">
              {socialLinks.map(({ platform, href, label }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="text-white/90 hover:text-brand-cyan"
                >
                  <SocialIcon platform={platform} className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
