import { useState } from "react";
import { Link } from "react-router-dom";
import { Menu, X } from "lucide-react";
import SocialIcon, { SocialPlatform } from "./SocialIcon";

const navLinks = [
  { label: "Inicio", to: "/" },
  { label: "Nosotros", to: "/nosotros" },
  { label: "Servicios", to: "/servicios" },
  { label: "Precios", to: "/precios" },
  { label: "Páginas", to: "/paginas" },
  { label: "Contacto", to: "/contacto" },
];

const socialLinks: { platform: SocialPlatform; href: string; label: string }[] = [
  { platform: "facebook", href: "https://facebook.com", label: "Facebook" },
  { platform: "twitter", href: "https://twitter.com", label: "Twitter" },
  { platform: "instagram", href: "https://instagram.com", label: "Instagram" },
  { platform: "linkedin", href: "https://linkedin.com", label: "LinkedIn" },
  { platform: "youtube", href: "https://youtube.com", label: "YouTube" },
];

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="w-full bg-white">
      <div className="hidden items-center justify-between border-b border-slate-100 px-6 py-2 text-sm font-semibold text-slate-500 md:flex lg:px-[80px]">
        <a href="tel:+542614494000" className="hover:text-brand-cyan">
          +54 261 449 4000
        </a>
        <div className="flex items-center gap-4">
          {socialLinks.map(({ platform, href, label }) => (
            <a
              key={label}
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={label}
              className="text-slate-900 hover:text-brand-cyan"
            >
              <SocialIcon platform={platform} className="h-4 w-4" />
            </a>
          ))}
        </div>
      </div>
      <div className="flex items-center justify-between px-6 py-5 lg:px-[80px]">
        <Link
          to="/"
          className="font-inter text-2xl font-bold text-brand-cyan sm:text-[26px]"
        >
          Medicuyo
        </Link>
        <nav className="hidden items-center gap-8 lg:flex">
          {navLinks.map((link) => (
            <Link
              key={link.label}
              to={link.to}
              className="text-base font-bold text-brand-navy hover:text-brand-cyan"
            >
              {link.label}
            </Link>
          ))}
        </nav>
        <button
          type="button"
          aria-label="Abrir menú"
          className="text-brand-navy lg:hidden"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="h-7 w-7" /> : <Menu className="h-7 w-7" />}
        </button>
      </div>
      {open && (
        <nav className="flex flex-col gap-1 border-t border-slate-100 px-6 pb-4 lg:hidden">
          {navLinks.map((link) => (
            <Link
              key={link.label}
              to={link.to}
              onClick={() => setOpen(false)}
              className="rounded-md px-2 py-2 text-base font-bold text-brand-navy hover:bg-slate-50 hover:text-brand-cyan"
            >
              {link.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}
