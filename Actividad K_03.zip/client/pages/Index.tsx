import { useState } from "react";
import { ArrowLeft, ArrowRight } from "lucide-react";
import Layout from "@/components/layout/Layout";

const testimonials = [
  {
    quote:
      "La atención recibida fue excelente desde el primer momento. Todo el equipo médico demostró una gran calidez humana y profesionalismo en el diagnóstico.",
    name: "Nombre del Paciente",
    avatar:
      "https://api.builder.io/api/v1/image/assets/TEMP/18b7146c95934734360344e021a0fdeef2f48266?width=360",
  },
  {
    quote:
      "Desde el turno hasta la consulta, todo fue rápido y muy claro. Me sentí escuchada y bien acompañada durante todo el proceso.",
    name: "Nombre del Paciente",
    avatar:
      "https://api.builder.io/api/v1/image/assets/TEMP/18b7146c95934734360344e021a0fdeef2f48266?width=360",
  },
  {
    quote:
      "Recomiendo Medicuyo por la calidad humana de sus profesionales y la tecnología que utilizan para brindar diagnósticos precisos.",
    name: "Nombre del Paciente",
    avatar:
      "https://api.builder.io/api/v1/image/assets/TEMP/18b7146c95934734360344e021a0fdeef2f48266?width=360",
  },
];

export default function Index() {
  const [active, setActive] = useState(0);
  const testimonial = testimonials[active];

  const goPrev = () =>
    setActive((i) => (i - 1 + testimonials.length) % testimonials.length);
  const goNext = () => setActive((i) => (i + 1) % testimonials.length);

  return (
    <Layout>
      <section className="px-6 pb-16 pt-16 text-center sm:pt-20 lg:pb-20 lg:pt-24">
        <div className="mx-auto flex max-w-[770px] flex-col items-center gap-4">
          <h2 className="text-2xl font-semibold text-brand-cyan sm:text-[29px]">
            Testimonios
          </h2>
          <div className="h-2 w-[177px] bg-slate-200" />
          <h1 className="text-4xl font-bold leading-tight text-brand-navy sm:text-5xl lg:text-[60px]">
            Lo Que Dicen Los Pacientes De Nuestros Servicios
          </h1>
        </div>
      </section>

      <section className="px-6 pb-24 sm:pb-32">
        <div className="mx-auto flex max-w-[770px] flex-col items-center text-center">
          <span className="text-lg font-bold text-brand-cyan">
            TESTIMONIOS
          </span>
          <h2 className="mt-3 text-3xl font-bold text-brand-navy sm:text-4xl">
            Lo que Opinan Nuestros Pacientes
          </h2>

          <img
            src={testimonial.avatar}
            alt={testimonial.name}
            className="mt-10 h-[140px] w-[140px] rounded-full object-cover sm:h-[180px] sm:w-[180px]"
          />

          <p className="mt-10 max-w-[700px] text-lg font-bold leading-relaxed tracking-wide text-slate-600">
            {testimonial.quote}
          </p>

          <p className="mt-8 text-xl font-bold text-brand-navy sm:text-[22px]">
            {testimonial.name}
          </p>

          <div className="mt-10 flex items-center gap-4">
            <button
              type="button"
              onClick={goPrev}
              aria-label="Testimonio anterior"
              className="flex h-[45px] w-[45px] items-center justify-center rounded-full bg-brand-cyan text-white transition hover:brightness-95"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={goNext}
              aria-label="Siguiente testimonio"
              className="flex h-[45px] w-[45px] items-center justify-center rounded-full bg-brand-cyan text-white transition hover:brightness-95"
            >
              <ArrowRight className="h-5 w-5" />
            </button>
          </div>
        </div>
      </section>
    </Layout>
  );
}
