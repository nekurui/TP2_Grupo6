import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import Layout from "@/components/layout/Layout";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center px-6 py-24 text-center sm:py-32">
        <h1 className="text-4xl font-bold text-brand-navy">404</h1>
        <p className="mt-4 text-lg font-medium text-slate-500">
          Oops! Esta página no existe.
        </p>
        <Link
          to="/"
          className="mt-8 rounded-[5px] bg-brand-cyan px-6 py-3 text-sm font-bold text-white hover:brightness-95"
        >
          Volver al inicio
        </Link>
      </div>
    </Layout>
  );
};

export default NotFound;
