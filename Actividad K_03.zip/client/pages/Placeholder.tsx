import { Link } from "react-router-dom";
import Layout from "@/components/layout/Layout";

export default function Placeholder({ title }: { title: string }) {
  return (
    <Layout>
      <div className="mx-auto flex max-w-[700px] flex-col items-center px-6 py-24 text-center sm:py-32">
        <span className="text-sm font-bold uppercase tracking-wide text-brand-cyan">
          Próximamente
        </span>
        <h1 className="mt-4 text-3xl font-bold text-brand-navy sm:text-4xl">
          {title}
        </h1>
        <p className="mt-4 text-base font-medium text-slate-500">
          Esta página todavía no tiene contenido. Seguí conversando con
          Fusion para completarla.
        </p>
        <Link
          to="/"
          className="mt-8 rounded-[5px] bg-brand-cyan px-6 py-3 text-sm font-bold text-white hover:brightness-95"
        >
          Volver al inicio
        </Link>
      </div>
    </Layout>
  );
}
